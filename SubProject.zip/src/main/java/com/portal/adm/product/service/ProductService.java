package com.portal.adm.product.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.portal.adm.packagingCode.model.PackagingCodeModel;
import com.portal.adm.product.mapper.ProductMapper;
import com.portal.adm.product.model.ProdPackagingModel;
import com.portal.adm.product.model.ProductModel;
import com.portal.common.Constant;

/**
 * 제품코드 서비스 클래스
 */
@Service
public class ProductService {

    @Resource
    private ProductMapper productMapper;

    /**
	 * 상품관리 목록을 조회한다.
	 *
	 * @param criteria 페이징 모델
	 * @return
	 */
    public List<ProductModel> selectProductList(ProductModel productModel) {
        return productMapper.selectProductList(productModel);
    }
    
    /**
	 * 상품 목록 카운트를 조회한다.
	 *
	 * @param criteria 페이징 모델
	 * @return
	 */
	public int selectProductListCount(ProductModel productModel) {
		return productMapper.selectProductListCount(productModel);
	}
    
	/**
	 * 상품아이디를 이용하여 상품정보를 조회한다.
	 *
	 * @param model productCode(상품코드)을 사용
	 * @return
	 */
	public ProductModel selectProduct(ProductModel productModel) {
		return productMapper.selectProduct(productModel);
	}
	
	
	/**
	 * 상품 정보를 등록한다.
	 *
	 * @param model 상품번호를 사용
	 * @return
	 */
	@Transactional
	public String insertProduct(ProductModel productModel) {
		long count = productMapper.insertProduct(productModel);
		
		if (count > 0) {
			return Constant.DB.INSERT;
		} else {
			return Constant.DB.FAIL;
		}
	}

	/**
	 * 상품 정보를 수정한다.
	 *
	 * @param model 상품번호를 사용
	 * @return
	 */
	@Transactional
	public String updateProduct(ProductModel productModel) {
		
		long count = productMapper.updateProduct(productModel);

		if (count > 0) {
			return Constant.DB.UPDATE;
		} else {
			return Constant.DB.FAIL;
		}
	}
	
	/**
	 * 상품 정보를 수정(삭제,미사용)한다.
	 *
	 * @param model 상품번호를 사용
	 * @return
	 */
	@Transactional
	public String deleteProduct(ProductModel productModel) {
		long count = productMapper.deleteProduct(productModel);
		if (count > 0) {
			return Constant.DB.DELETE;
		} else {
			return Constant.DB.FAIL;
		}
	}
	
	 /**
	 * 상품포장정보관리 목록 카운트를 조회한다.
	 *
	 * @param productPackagingModel
	 * @return
	 */
	public List<ProdPackagingModel> selectProductPackagingOrder(ProdPackagingModel productPackagingModel) {
		return productMapper.selectProductPackagingOrder(productPackagingModel);
	}
		
	/**
	 * 상품포장정보관리 목록을 조회한다.
	 *
	 * @param criteria 모델
	 * @return
	 */
    public List<ProdPackagingModel> selectProductPackaging(ProdPackagingModel productPackagingModel) {
        return productMapper.selectProductPackaging(productPackagingModel);
    }
	
    /**
	 * 상품포장정보관리 상세정보 조회한다.
	 *
	 * @param criteria 모델
	 * @return
	 */
    public ProdPackagingModel selectProductPackagingDetail(ProdPackagingModel productPackagingModel) {
        return productMapper.selectProductPackagingDetail(productPackagingModel);
    }
    
    /**
	 * 상품포장 정보를 등록한다.
	 *
	 * @param model 상품포장정보번호를 사용
	 * @return
	 */
	@Transactional
	public String insertProductPackaging(ProdPackagingModel productPackagingModel) {
		long count = productMapper.insertProductPackaging(productPackagingModel);
		
		if (count > 0) {
			return Constant.DB.INSERT;
		} else {
			return Constant.DB.FAIL;
		}
	}

	/**
	 * 상품포장정보 정보를 수정한다.
	 *
	 * @param model 상품포장정보번호를 사용
	 * @return
	 */
	@Transactional
	public String updateProductPackaging(ProdPackagingModel productPackagingModel) {
		
		long count = productMapper.updateProductPackaging(productPackagingModel);

		if (count > 0) {
			return Constant.DB.UPDATE;
		} else {
			return Constant.DB.FAIL;
		}
	}
	
	/**
	 * 상품포장정보 정보를 수정(삭제,미사용)한다.
	 *
	 * @param model 상품포장정보번호를 사용
	 * @return
	 */
	@Transactional
	public String deleteProductPackaging(ProdPackagingModel productPackagingModel) {
		long count = productMapper.deleteProductPackaging(productPackagingModel);
		if (count > 0) {
			return Constant.DB.DELETE;
		} else {
			return Constant.DB.FAIL;
		}
	}
	
	/**
	 *  재질정보 조회한다.
	 *
	 * @param
	 * @return
	 */
	public List<PackagingCodeModel> selectProductMatType() {
        return productMapper.selectProductMatType();
    }
}

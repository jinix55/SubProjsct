package com.portal.adm.product;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FilenameUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartRequest;

import com.portal.adm.environmentCode.model.EnvironmentCodeModel;
import com.portal.adm.environmentCode.service.EnvironmentCodeService;
import com.portal.adm.file.model.FileModel;
import com.portal.adm.file.service.FileService;
import com.portal.adm.member.model.MemberModel;
import com.portal.adm.member.service.MemberService;
import com.portal.adm.packagingCode.model.PackagingCodeModel;
import com.portal.adm.product.model.ProdPackagingModel;
import com.portal.adm.product.model.ProductModel;
import com.portal.adm.product.service.ProductService;
import com.portal.adm.supplier.model.SupplierModel;
import com.portal.adm.supplier.service.SupplierService;
import com.portal.common.Constant;
import com.portal.common.IdUtil;
import com.portal.config.security.AuthUser;

import lombok.extern.slf4j.Slf4j;

/**
 * 상품관리 / 상품 컨트롤러
 */
@Slf4j
@RequestMapping("/product")
@Controller
public class ProductController {

    @Resource
    private ProductService productService;
    
    @Resource
	private SupplierService supplierService;
    
	@Resource
    private MemberService memberService;
	
    @Resource
    private IdUtil idUtil;
    
    @Resource(name="fileService")
	private FileService fileService;
    
    @Resource
    private EnvironmentCodeService environmentCodeService;
    
    /**
     * 상품 페이지로 이동
     *
     * @param model
     * @return
     */
    @RequestMapping(value="/prodList", method= {RequestMethod.GET,RequestMethod.POST})
    public String product(@ModelAttribute ProductModel productModel, Model model, @AuthenticationPrincipal AuthUser authUser) {
    	// 상품 목록 조회
    	List<ProductModel> models = productService.selectProductList(productModel);
    	productModel.setTotalCount(productService.selectProductListCount(productModel));
        model.addAttribute("products", models);
        model.addAttribute("pages", productModel);
    	
        //상품분류 정보 조회
    	List<String> productTypeList = new ArrayList<>();
    	productTypeList.add("제품분류113");
    	productTypeList.add("제품분류223");
    	model.addAttribute("productTypeList", productTypeList);        
    	
    	//재질 정보 조회
    	List<PackagingCodeModel> productMatType = productService.selectProductMatType();
    	model.addAttribute("productMatTypeList", productMatType);  
    	
    	//공급업체 정보 조회
    	SupplierModel supplierModel = new SupplierModel();
    	supplierModel.setAuthId(authUser.getMemberModel().getAuthId());
    	supplierModel.setOffSet(0);
    	supplierModel.setPageSize(9999);
        List<SupplierModel> supplierList = supplierService.selectSupplierList(supplierModel);
        model.addAttribute("suppliers", supplierList);
        
        return "product/prodList";
    }

    /**
     * 상품 상세정보를 조회한다.
     *
     * @param productId
     * @return
     */
    @RequestMapping(value="/detail/{productId}", method= {RequestMethod.GET,RequestMethod.POST})
    @ResponseBody
    public ResponseEntity<ProductModel> selectProduct(@PathVariable("productId") String productId) {
    	//상품 상세정보 조회
    	ProductModel productModel = new ProductModel();
    	productModel.setProductId(productId);
//    	productModel.setProductCode(productId);
    	ProductModel product = productService.selectProduct(productModel);
		
        return new ResponseEntity<>(product, HttpStatus.OK);
    }
    
    /**
     * 상품을 저장한다.
     *
     * @param request
     * @return
     */
    @RequestMapping(value="/insert" , method= {RequestMethod.GET,RequestMethod.POST}, produces=MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<String> groupSave(HttpServletRequest request, @ModelAttribute ProductModel productModel,@AuthenticationPrincipal AuthUser authUser,  MultipartRequest multipart) {
    	try {
    		productModel.setProductId(idUtil.getProductId());
    		productModel.setRgstId(authUser.getMemberModel().getUserId());
    		productModel.setModiId(authUser.getMemberModel().getUserId());
    		
    		final Map<String, MultipartFile> files = multipart.getFileMap();
    		ArrayList<String> fileIds = new ArrayList<String>();
    		String fileId = "";
    		String fileUrl = "C:/" + productModel.getProductId() + "/";
    		String result = "success";
    		String resultMessage = "성공";
    		MultipartFile file = null;
    		for (String key : files.keySet()) {
    			file = files.get(key);
    			if(file.getOriginalFilename().equals("")) {
    				break;
    				//return new ResponseEntity<>("notFile", HttpStatus.NOT_ACCEPTABLE);
    			}
    			FileModel f = new FileModel();
    			fileId = idUtil.getFileId();
    			fileIds.add(fileId);
    			f.setFileId(fileId);
    			// s3 기본 처리
    			// f.setStorageSe("");
    			// f.setSavePath("");
    			// f.setBucketNm("");
    			// f.setSaveFileVer("");
    			// f.setSaveFileNm("");

    			// s3 기본 처리
    			f.setStorageSe("LOCAL");
    			f.setFileNm(file.getOriginalFilename());
    			f.setFileExtsn(FilenameUtils.getExtension(file.getOriginalFilename()));
    			f.setFileSize(file.getSize());
    			f.setFileUrl(fileUrl);
    			f.setUseYn("Y");
    			f.setRgstId(productModel.getRgstId());
    			f.setModiId(productModel.getRgstId());
    			f.setFileCl(Constant.File.API);
    			f.setRefId(productModel.getProductId());
    			try {
    				f.setInputStream(file.getResource().getInputStream());
    			} catch (IOException e) {
    				// TODO Auto-generated catch block
    				result = "fail";
    				resultMessage = "실패";
    			}
    			// 파일 생성
    			if (!"fail".equals(result)) {
    				fileService.insertFile(f);
//    				insertFile(f);
    				productModel.setPhoto(fileId);

    				Path directoryPath = Paths.get(fileUrl);

    				try {
    					Files.createDirectories(directoryPath);
    				} catch (IOException e1) {
    					// TODO Auto-generated catch block
    					e1.printStackTrace();
    				}

    				try {
    					FileOutputStream fos = new FileOutputStream(fileUrl + file.getOriginalFilename());

    					InputStream is = file.getInputStream();

    					int readCount = 0;
    					byte[] buffer = new byte[1024];
    					// 파일을 읽을 크기 만큼의 buffer를 생성하고
    					// ( 보통 1024, 2048, 4096, 8192 와 같이 배수 형식으로 버퍼의 크기를 잡는 것이 일반적이다.)

    					while ((readCount = is.read(buffer)) != -1) {
    						// 파일에서 가져온 fileInputStream을 설정한 크기 (1024byte) 만큼 읽고

    						fos.write(buffer, 0, readCount);
    						// 위에서 생성한 fileOutputStream 객체에 출력하기를 반복한다
    					}
    				} catch (FileNotFoundException e) {
    					// TODO Auto-generated catch block
    					e.printStackTrace();
    				}
//    				 if (s3Util.upload(f)) {
//    					 log.debug("s3 upload success!");
//    					 updateFile(f);
//    				 }else {
//    					 result = "fail";
//    					 resultMessage = "실패";
//    				 }
    				// 운영에 배포시 삭제
    				// updateFile(f);
    				// result = "success";
    				// resultMessage = "성공";
    				catch (IOException e) {
    					// TODO Auto-generated catch block
    					e.printStackTrace();
    				}
    				
    				
    			}
    			fileUrl = f.getFileUrl();
    		}
    		
    		
            result = productService.insertProduct(productModel);

            return new ResponseEntity<>(result, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_ACCEPTABLE);
        }
    }
    
//    @PostMapping("/update")
    @RequestMapping(value="/update" , method= {RequestMethod.GET,RequestMethod.POST}, produces=MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<String> update(HttpServletRequest request,
                                       @ModelAttribute ProductModel productModel,
                                       @AuthenticationPrincipal AuthUser authUser,  MultipartRequest multipart) {

        try {
    		productModel.setModiId(authUser.getMemberModel().getUserId());
            String result = productService.updateProduct(productModel);

            return new ResponseEntity<>(result, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_ACCEPTABLE);
        }
    }
    
    /**
     * 상품을 삭제한다.
     *
     * @param request
     * @return
     */
    @PostMapping("/delete")
    public ResponseEntity<String> productDelete(@ModelAttribute ProductModel productModel, HttpServletRequest request, @AuthenticationPrincipal AuthUser authUser) {
        try {            
            productModel.setModiId(authUser.getMemberModel().getUserId());
            String result = productService.deleteProduct(productModel);
            
            return new ResponseEntity<>(result, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_ACCEPTABLE);
        }
    }    
    
    
    @RequestMapping(value="/detail/packagingOrder", method= {RequestMethod.GET,RequestMethod.POST})
    @ResponseBody
    public ResponseEntity<List<ProdPackagingModel>> selectProductPackagingOrder(@ModelAttribute ProdPackagingModel productPackagingModel) {
    	// 상품 포장 차수 조회
    	List<ProdPackagingModel> packagingOrder = productService.selectProductPackagingOrder(productPackagingModel);
    	
        return new ResponseEntity<>(packagingOrder, HttpStatus.OK);
    }
    
    @RequestMapping(value="/detail/packaging", method= {RequestMethod.GET,RequestMethod.POST})
    @ResponseBody
    public ResponseEntity<List<ProdPackagingModel>> selectProductPackaging(@ModelAttribute ProdPackagingModel productPackagingModel) {
    	// 상품 목록 조회
    	List<ProdPackagingModel> models = productService.selectProductPackaging(productPackagingModel);
        return new ResponseEntity<>(models, HttpStatus.OK);
    }

    /**
     * 상품포장정보 상세정보를 조회한다.
     *
     * @param productId
     * @return
     */
    @RequestMapping(value="/detail/{productId}/packaging/{packagingId}", method= {RequestMethod.GET,RequestMethod.POST})
    @ResponseBody
    public ResponseEntity<ProdPackagingModel> selectProduct(@PathVariable("productId") String productId, @PathVariable("packagingId") String packagingId) {
    	ProdPackagingModel prodPackagingModel = new ProdPackagingModel();
    	prodPackagingModel.setPackagingId(packagingId);
    	prodPackagingModel.setProductId(productId);
    	ProdPackagingModel productPackaging = productService.selectProductPackagingDetail(prodPackagingModel);
    	if(productPackaging.getMatFileId() != null && !"".equals(productPackaging.getMatFileId())) {
    		FileModel f = new FileModel();
    		f.setFileId(productPackaging.getMatFileId());
    		FileModel f1 = fileService.selectFile(f);
    		if(f1 != null) {
    			productPackaging.setMatFileNm(f1.getFileNm());
//    			productPackaging.setMatFileId(f1.getFileUrl());
    		}else {
    			productPackaging.setMatFileId("");
    			productPackaging.setMatFileNm("");
    		}
    	}else {
    		productPackaging.setMatFileId("");
			productPackaging.setMatFileNm("");
    	}
    	
        return new ResponseEntity<>(productPackaging, HttpStatus.OK);
    }
    
    /**
     * 상품포장정보을 저장한다.
     *
     * @param request
     * @return
     */
    @PostMapping("/insert/{productId}/packaging")
    public ResponseEntity<ProdPackagingModel> insertProductPackaging(HttpServletRequest request, @PathVariable("productId") String productId, @ModelAttribute ProdPackagingModel prodPackagingModel,@AuthenticationPrincipal AuthUser authUser) {
    	try {
    		
			prodPackagingModel.setRgstId(authUser.getMemberModel().getUserId());
			prodPackagingModel.setModiId(authUser.getMemberModel().getUserId());
			prodPackagingModel.setProductId(productId);
			prodPackagingModel.setProductNm("상품1");
			prodPackagingModel.setPackagingNm("1차포장");
			prodPackagingModel.setPackagingId(idUtil.getPackagingId());
			int x= prodPackagingModel.getManagerId().indexOf("||");
			String managerId = prodPackagingModel.getManagerId().substring(0, x);
        	prodPackagingModel.setManagerId(managerId);
			productService.insertProductPackaging(prodPackagingModel);

            return new ResponseEntity<>(prodPackagingModel, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(new ProdPackagingModel(), HttpStatus.NOT_ACCEPTABLE);
        }
    }
    
    @PostMapping("/update/{productId}/packaging")
    public ResponseEntity<ProdPackagingModel> updateProductPackaging(HttpServletRequest request, @PathVariable("productId") String productId,
                                       @ModelAttribute ProdPackagingModel prodPackagingModel,
                                       @AuthenticationPrincipal AuthUser authUser) {

        try {
        	prodPackagingModel.setModiId(authUser.getMemberModel().getUserId());
        	prodPackagingModel.setProductNm("상품1");
			prodPackagingModel.setPackagingNm("1차포장");
			int x= prodPackagingModel.getManagerId().indexOf("||");
			String managerId = prodPackagingModel.getManagerId().substring(0, x);
        	prodPackagingModel.setManagerId(managerId);
            productService.updateProductPackaging(prodPackagingModel);

            return new ResponseEntity<>(prodPackagingModel, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(new ProdPackagingModel(), HttpStatus.NOT_ACCEPTABLE);
        }
    }
    
    /**
     * 상품포장정보을 삭제한다.
     *
     * @param request
     * @return
     */
    @PostMapping("/delete/{productId}/packaging")
    public ResponseEntity<String> deleteProductPackaging(@ModelAttribute ProdPackagingModel prodPackagingModel, HttpServletRequest request, @AuthenticationPrincipal AuthUser authUser) {
        try {            
        	prodPackagingModel.setModiId(authUser.getMemberModel().getUserId());
            String result = productService.deleteProductPackaging(prodPackagingModel);
            
            return new ResponseEntity<>(result, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_ACCEPTABLE);
        }
    } 
    
    /**
     * 코드변경시점정보를 조회한다.
     *
     * @param productId
     * @return
     */
    @RequestMapping(value="/detail/getCodeDayList", method= {RequestMethod.GET,RequestMethod.POST})
    @ResponseBody
    public ResponseEntity<List<EnvironmentCodeModel>> getCodeDayList() {
    	List<EnvironmentCodeModel> dayList = environmentCodeService.selectCodeDayList();
    	
        return new ResponseEntity<>(dayList, HttpStatus.OK);
    }
    
    /**
     * 상품 페이지로 이동
     *
     * @param criteria
     * @return
     */
    @RequestMapping(value="/prodImage", method= {RequestMethod.GET,RequestMethod.POST})
    public String codePost(@ModelAttribute ProductModel productModel, Model model, @AuthenticationPrincipal AuthUser authUser) {

    	// 상품 목록 조회
    	List<ProductModel> models = productService.selectProductList(productModel);
    	productModel.setTotalCount(productService.selectProductListCount(productModel));
        model.addAttribute("products", models);
        model.addAttribute("pages", productModel);
        
        return "product/prodImage";
    }

    
    
    /**
     * 공급업체 페이지로 이동
     *
     * @param model
     * @return
     */
    @RequestMapping(value="/supplier", method= {RequestMethod.GET,RequestMethod.POST})
    public String code(@ModelAttribute SupplierModel supplierModel, Model model, @AuthenticationPrincipal AuthUser authUser) {
    	supplierModel.setUpCompanyCode(authUser.getMemberModel().getCompanyCode());
    	supplierModel.setAuthId(authUser.getMemberModel().getAuthId());
        List<SupplierModel> models = supplierService.selectSupplierList(supplierModel);
        supplierModel.setTotalCount(supplierService.selectSupplierListCount(supplierModel));
        
        for( int i = 0 ; i < models.size() ; i++) {
        	MemberModel memberModel = new MemberModel();
        	
        	String memId = models.get(i).getManagementId();
        	memberModel.setUserId(memId);
        	memberModel = memberService.selectMember(memberModel);
        	models.get(i).setManagementId(memId);
        	models.get(i).setManagementNm(memberModel.getUserNm());
        	models.get(i).setManagementPhone(memberModel.getPhone());
        	models.get(i).setManagementMail(memberModel.getEmail());
        	models.get(i).setManagementDept(memberModel.getDeptNm());
        	models.get(i).setManagementPstn(memberModel.getPstnNm());
        }
        
        model.addAttribute("suppliers", models);
        model.addAttribute("pages", supplierModel);
        
        return "product/supplierView";
    }

    /**
     * 공급업체 목록을 상세 조회한다.
     *
     * @param groupCd
     * @return
     */
    @RequestMapping(value="/supplier/detail/{supplierId}", method= {RequestMethod.GET,RequestMethod.POST})
    @ResponseBody
    public ResponseEntity<SupplierModel> codesForGroupCd(@ModelAttribute SupplierModel supplierModel, @PathVariable("supplierId") String supplierId) {
    	supplierModel = supplierService.selectSupplierId(supplierId);
    	return new ResponseEntity<>(supplierModel, HttpStatus.OK);
    }
    
    /**
     * 공급업체 책임자를 상세 조회한다.
     *
     * @param groupCd
     * @return
     */
    @RequestMapping(value="/supplier/detail/manager/{managerId}", method= {RequestMethod.GET,RequestMethod.POST})
    @ResponseBody
    public ResponseEntity<SupplierModel> selectManagerId(@ModelAttribute SupplierModel supplierModel, @PathVariable("managerId") String managerId) {
    	supplierModel = supplierService.selectSupplierManager(managerId);
        return new ResponseEntity<>(supplierModel, HttpStatus.OK);
    }
    
    /**
     * 그룹코드 목록을 조회한다.
     *
     * @param groupCd
     * @return
     */
    @RequestMapping(value="/supplier/detail/managers/{supplierCode}", method= {RequestMethod.GET,RequestMethod.POST})
    @ResponseBody
    public ResponseEntity<List<SupplierModel>> selectManagersBySupplierCode(@ModelAttribute SupplierModel supplierModel, @PathVariable("supplierCode") String supplierCode) {
    	List<SupplierModel> models = supplierService.selectSupplierManagers(supplierCode);
        return new ResponseEntity<>(models, HttpStatus.OK);
    }
    
}

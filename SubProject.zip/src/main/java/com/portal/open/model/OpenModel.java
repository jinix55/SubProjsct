package com.portal.open.model;

import lombok.Data;

/**
 * 포장 open 모델
 */
@Data
public class OpenModel {

}

package com.portal.open.mapper;

import com.portal.common.annotation.ConnMapperFirst;

/**
 * Mybatis 포장 open 화면 매핑 Interface
 */
@ConnMapperFirst
public interface OpenMapper {


}
